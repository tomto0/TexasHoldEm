package main

type Card struct {
	Suit  rune
	Value int
}
